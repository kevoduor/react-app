import { Platform } from 'react-native'

// Helper to select system font based on platform
const getSystemFont = () => {
  return Platform.select({
    ios: 'SF Pro Display',
    android: 'Roboto',
    default: 'System',
  })
}

export const typography = {
  fonts: {
    regular: getSystemFont(),
    medium: Platform.select({
      ios: 'SF Pro Display-Medium',
      android: 'Roboto-Medium',
      default: 'System-Medium',
    }),
    semibold: Platform.select({
      ios: 'SF Pro Display-Semibold',
      android: 'Roboto-Semibold',
      default: 'System-Semibold',
    }),
    bold: Platform.select({
      ios: 'SF Pro Display-Bold',
      android: 'Roboto-Bold',
      default: 'System-Bold',
    }),
  },
  sizes: {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 18,
    xl: 20,
    '2xl': 24,
    '3xl': 30,
    '4xl': 36,
    '5xl': 48,
  },
  lineHeights: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },
}

