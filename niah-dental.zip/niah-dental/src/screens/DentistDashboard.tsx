import React from 'react'
import { View, ScrollView, StyleSheet } from 'react-native'
import { AppHeader } from '../components/AppHeader'
import { colors } from '../theme/colors'
import { SafeAreaView } from 'react-native-safe-area-context'

export const DentistDashboard: React.FC = () => {
  const handleVoiceResult = (result: string) => {
    // Handle voice search results
    console.log('Voice search result:', result)
  }

  const handleMenuPress = () => {
    // Handle menu press
    console.log('Menu pressed')
  }

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <AppHeader
        title="Niah Dental"
        onVoiceResult={handleVoiceResult}
        onMenuPress={handleMenuPress}
      />
      <ScrollView style={styles.content}>
        {/* Add dashboard content here */}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  content: {
    flex: 1,
  },
})

