import React, { useState, useCallback } from 'react'
import { View, TouchableOpacity, StyleSheet, Text } from 'react-native'
import Voice from '@react-native-voice/voice'
import { OrganicSphere } from './OrganicSphere'
import { colors } from '../theme/colors'
import { typography } from '../theme/typography'

interface VoiceSearchProps {
  onResult?: (result: string) => void
  size?: 'small' | 'medium' | 'large'
}

export const VoiceSearch: React.FC<VoiceSearchProps> = ({
  onResult,
  size = 'medium',
}) => {
  const [isListening, setIsListening] = useState(false)
  const [partialResults, setPartialResults] = useState<string[]>([])

  const sphereSize = {
    small: 40,
    medium: 60,
    large: 80,
  }[size]

  const startListening = useCallback(async () => {
    try {
      await Voice.start('en-US')
      setIsListening(true)
    } catch (e) {
      console.error(e)
    }
  }, [])

  const stopListening = useCallback(async () => {
    try {
      await Voice.stop()
      setIsListening(false)
    } catch (e) {
      console.error(e)
    }
  }, [])

  React.useEffect(() => {
    Voice.onSpeechResults = (e) => {
      if (e.value && e.value[0] && onResult) {
        onResult(e.value[0])
      }
    }

    Voice.onSpeechPartialResults = (e) => {
      if (e.value) {
        setPartialResults(e.value)
      }
    }

    return () => {
      Voice.destroy().then(Voice.removeAllListeners)
    }
  }, [onResult])

  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPressIn={startListening}
        onPressOut={stopListening}
        style={styles.button}
      >
        <OrganicSphere size={sphereSize} color={colors.primary[500]} />
      </TouchableOpacity>
      {isListening && partialResults.length > 0 && (
        <Text style={styles.partialResult}>{partialResults[0]}</Text>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
  button: {
    padding: 12,
  },
  partialResult: {
    marginTop: 8,
    fontSize: typography.sizes.sm,
    color: colors.neutral[600],
    fontFamily: typography.fonts.regular,
  },
})

