import React from 'react'
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import { VoiceSearch } from './VoiceSearch'
import { colors } from '../theme/colors'
import { typography } from '../theme/typography'
import { SafeAreaView } from 'react-native-safe-area-context'

interface AppHeaderProps {
  title: string
  onVoiceResult?: (result: string) => void
  onMenuPress?: () => void
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  title,
  onVoiceResult,
  onMenuPress,
}) => {
  return (
    <SafeAreaView edges={['top']} style={styles.safeArea}>
      <View style={styles.container}>
        <TouchableOpacity onPress={onMenuPress} style={styles.menuButton}>
          <Text style={styles.menuIcon}>☰</Text>
        </TouchableOpacity>
        <Text style={styles.title}>{title}</Text>
        <VoiceSearch size="small" onResult={onVoiceResult} />
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: colors.white,
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral[200],
  },
  menuButton: {
    padding: 8,
  },
  menuIcon: {
    fontSize: typography.sizes.xl,
    color: colors.neutral[800],
  },
  title: {
    fontSize: typography.sizes.lg,
    fontFamily: typography.fonts.semibold,
    color: colors.neutral[900],
    flex: 1,
    textAlign: 'center',
  },
})

