import React, { useEffect, useRef } from 'react'
import { View, StyleSheet, Animated } from 'react-native'
import { Canvas, Circle, vec } from '@shopify/react-native-skia'
import Voice from '@react-native-voice/voice'

interface OrganicSphereProps {
  size?: number
  color?: string
}

export const OrganicSphere: React.FC<OrganicSphereProps> = ({
  size = 100,
  color = '#2196F3',
}) => {
  const amplitude = useRef(new Animated.Value(1)).current
  const phase = useRef(new Animated.Value(0)).current

  useEffect(() => {
    // Animate the sphere continuously
    Animated.loop(
      Animated.parallel([
        Animated.sequence([
          Animated.timing(amplitude, {
            toValue: 1.2,
            duration: 2000,
            useNativeDriver: true,
          }),
          Animated.timing(amplitude, {
            toValue: 1,
            duration: 2000,
            useNativeDriver: true,
          }),
        ]),
        Animated.loop(
          Animated.timing(phase, {
            toValue: 1,
            duration: 3000,
            useNativeDriver: true,
          })
        ),
      ])
    ).start()

    // Setup voice detection
    Voice.onSpeechStart = () => {
      Animated.timing(amplitude, {
        toValue: 1.5,
        duration: 200,
        useNativeDriver: true,
      }).start()
    }

    Voice.onSpeechEnd = () => {
      Animated.timing(amplitude, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start()
    }

    return () => {
      Voice.destroy().then(Voice.removeAllListeners)
    }
  }, [])

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Canvas style={StyleSheet.absoluteFill}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={size / 3}
          color={color}
          style="fill"
        />
      </Canvas>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
})

